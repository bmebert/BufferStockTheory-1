
This directory contains the code that constructs all figures and results in the paper.  

Open the Mathematica notebook doAll.nb and execute the cells
sequentially to produce the paper's results.

